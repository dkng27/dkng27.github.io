class Drawing:
    def __init__(self, data, public=False):
        self.data = data
        self.width = len(data[0]) if data and len(data) > 0 else 0
        self.height = len(data) if data else 0
        self.public = public