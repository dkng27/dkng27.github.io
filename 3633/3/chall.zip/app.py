from flask import Flask, make_response, render_template, request, redirect, url_for, jsonify, abort
from flask_login import (
    LoginManager,
    login_user,
    logout_user,
    login_required,
    current_user,
)
from flask_cors import CORS
from werkzeug.security import check_password_hash
import secrets
from selenium import webdriver
from selenium.webdriver.common.by import By

# Import models
from models.user import User
from data import *

app = Flask(__name__)
CORS(app, supports_credentials=True, origins="*", expose_headers=["Set-Cookie"])
app.secret_key = secrets.token_hex(16)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


@login_manager.user_loader
def load_user(user_id):
    if user_id in USERS:
        return User(user_id)
    return None


@app.route("/")
def home():
    public_drawings = get_all_public_drawings()
    if current_user.is_authenticated:
        return render_template(
            "home.html",
            public_drawings=public_drawings,
            private_drawings=get_user_private_drawings(current_user.id),
        )
    return render_template("home.html", public_drawings=public_drawings)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        user_data = get_user(username)

        if user_data and check_password_hash(user_data["password"], password):
            user = User(username)
            login_user(user)
            return redirect(url_for("home"))

        return render_template("login.html", error="Invalid credentials")

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("home"))


@app.route("/pic/<username>/<drawing_name>")
def view_drawing(username, drawing_name):

    drawing = get_drawing(username, drawing_name)
    if not drawing:
        abort(404)

    if drawing.public or (
        current_user.is_authenticated and current_user.id == username
    ):
        response = make_response(render_template(
            "view.html", username=username, drawing_name=drawing_name, drawing=drawing
        ))
        response.headers["SameSite"] = "None; Secure"
        return response
    else:
        abort(403)

driver = None

def ready_bot():
    global driver
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--no-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-cache")
    chrome_options.add_argument("--disable-dev-shm-usage")
    
    driver = webdriver.Chrome(options=chrome_options)
    driver.implicitly_wait(5)

    admin_username = "admin"
    admin_password = os.getenv("ADMIN_PW", "apw")
    driver.get("http://localhost:80/login")
    driver.find_element(By.NAME, "username").send_keys(admin_username)
    driver.find_element(By.NAME, "password").send_keys(admin_password)
    driver.find_element(By.TAG_NAME, "form").submit()

@app.route("/share", methods=["GET", "POST"])
def share():
    global driver
    if request.method == "POST":
        url = request.form.get("url")
        if not url:
            return "URL is required", 400
        else:
            if driver is None:
                ready_bot()
            try:
                driver.get(url)
                return "Understood we are checking", 200
            except Exception as e:
                print(f"Bot navigation error: {e}")
                return "Ooopsy", 500

    return render_template("share.html")


if __name__ == "__main__":
    app.run("0.0.0.0", port=80, debug=True)
