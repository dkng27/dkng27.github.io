document.addEventListener("DOMContentLoaded", function () {
  const pixelDisplay = document.querySelector(".pixel-display");
  const pixels = document.querySelectorAll(".pixel");
  const selectionStatus = document.getElementById("selection-status");
  const cancelSelectionBtn = document.getElementById("cancel-selection");
  const iframeContainer = document.getElementById("iframe-container");
  const selectionLink = document.getElementById("selection-link");

  let selecting = false;
  let startRow, startCol, endRow, endCol;
  let selectedPixels = new Set();

  // Initialize pixel coordinates
  pixels.forEach((pixel) => {
    const row = pixel.getAttribute("data-row");
    const col = pixel.getAttribute("data-col");
    pixel.setAttribute("data-id", `${row}-${col}`);
  });

  const urlParams = new URLSearchParams(window.location.search);
  console.log(urlParams.toString());
  const hasSelection = urlParams.get("select");

  if (hasSelection) {
    // Get selection coordinates from URL
    startRow = parseInt(urlParams.get("minRow"));
    startCol = parseInt(urlParams.get("minCol"));
    endRow = parseInt(urlParams.get("maxRow"));
    endCol = parseInt(urlParams.get("maxCol"));
    selecting = false;
    updateSelection();
    checkSelectionContent();
  }
  
  // Selection events
  pixelDisplay.addEventListener("mousedown", function (e) {
    const pixel = e.target.closest(".pixel");
    if (!pixel) return;

    selecting = true;
    clearSelection();

    startRow = parseInt(pixel.getAttribute("data-row"));
    startCol = parseInt(pixel.getAttribute("data-col"));
    endRow = startRow;
    endCol = startCol;

    updateSelection();

    e.preventDefault();
  });

  document.addEventListener("mousemove", function (e) {
    if (!selecting) return;

    const pixel = e.target.closest(".pixel");
    if (!pixel) return;

    endRow = parseInt(pixel.getAttribute("data-row"));
    endCol = parseInt(pixel.getAttribute("data-col"));

    updateSelection();
  });

  document.addEventListener("mouseup", function () {
    if (!selecting) return;

    selecting = false;
    checkSelectionContent();
    cancelSelectionBtn.style.display = "inline-block";
  });

  // Update visual selection
  function updateSelection() {
    clearSelection();

    // Get min/max coordinates to handle selection in any direction
    const minRow = Math.min(startRow, endRow);
    const maxRow = Math.max(startRow, endRow);
    const minCol = Math.min(startCol, endCol);
    const maxCol = Math.max(startCol, endCol);

    selectionStatus.style.display = "none";
    selectionLink.style.display = "inline-block";
    selectionLink.href = `${window.location.pathname}?select=1&minRow=${minRow}&minCol=${minCol}&maxRow=${maxRow}&maxCol=${maxCol}`;

    // Track selected pixels for later use
    for (let row = minRow; row <= maxRow; row++) {
      for (let col = minCol; col <= maxCol; col++) {
        const id = `${row}-${col}`;
        selectedPixels.add(id);
      }
    }
    for (let row = minRow; row <= maxRow; row++) {
      for (let col = minCol; col <= maxCol; col++) {
        const isEdge =
          row === minRow || row === maxRow || col === minCol || col === maxCol;

        if (isEdge) {
          const id = `${row}-${col}`;
          const pixel = document.querySelector(`.pixel[data-id="${id}"]`);

          if (pixel) {
            pixel.classList.add("selected");
            if (row === minRow) pixel.classList.add("selected-top");
            if (row === maxRow) pixel.classList.add("selected-bottom");
            if (col === minCol) pixel.classList.add("selected-left");
            if (col === maxCol) pixel.classList.add("selected-right");
          }
        }
      }
    }
  }

  function clearSelection() {
    pixels.forEach((pixel) => {
      pixel.classList.remove("selected");
      pixel.classList.remove("selected-top");
      pixel.classList.remove("selected-bottom");
      pixel.classList.remove("selected-left");
      pixel.classList.remove("selected-right");
    });
    selectedPixels.clear();
    cancelSelectionBtn.style.display = "none";
    iframeContainer.style.display = "none";
    iframeContainer.innerHTML = "";
    selectionStatus.style.display = "inline-block";
    selectionLink.style.display = "none";
  }

  // Check if selection has any active pixels
  function checkSelectionContent() {
    let hasActivePixels = false;

    selectedPixels.forEach((id) => {
      const pixel = document.querySelector(`.pixel[data-id="${id}"]`);
      if (pixel && pixel.classList.contains("active")) {
        hasActivePixels = true;
      }
    });

    const header = document.createElement("h2");
    header.style.textAlign = "center";
    if (hasActivePixels) {
      createSelectionIframe();
      header.textContent = "AI enhancements";
    } else {
      header.textContent = "Selection is empty";
      iframeContainer.style.display = "block";
    }
    iframeContainer.appendChild(header);
  }

  // Create iframe with copy buttons
  function createSelectionIframe() {
    const iframe = document.createElement("iframe");
    iframe.src =
      "https://www.youtube.com/embed/xy2AUq3V8hc?autoplay=1&mute=1&loop=1&showinfo=0&rel=0"; // not ready yet, but investors don't care
    iframe.style.width = "100%";
    iframe.style.height = "100%";
    iframe.style.border = "none";
    iframe.style.borderRadius = "8px";

    iframeContainer.style.display = "block";
    iframeContainer.appendChild(iframe);
  }

  // Cancel selection button
  cancelSelectionBtn.addEventListener("click", function () {
    clearSelection();
    selectionStatus.textContent = "Click and drag to select";
    cancelSelectionBtn.style.display = "none";
  });
});
