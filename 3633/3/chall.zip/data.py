import os
from werkzeug.security import generate_password_hash

from models.drawing import Drawing
from PIL import Image
import numpy as np


def convert_image_to_array(file_path, max_size=43):
    try:
        img = Image.open(file_path)
        if img.mode != "L":
            img = img.convert("L")

        width, height = img.size
        if width > max_size or height > max_size:
            raise ValueError("Image exceeds maximum size")

        return (np.array(img) < 128).astype(int).tolist()

    except Exception as e:
        print(f"Error converting image: {e}")
        return None


USERS = {
    "admin": {
        "password": generate_password_hash(os.getenv("ADMIN_PW", "apw")),
        "drawings": {
            "flag": {
                "data": convert_image_to_array("./images/flag.png", max_size=33),
                "public": False,
            },
            "hkust": {
                "data": convert_image_to_array("./images/ust.png"),
                "public": True,
            },
            "smiley": {
                "data": convert_image_to_array("./images/smiley.png"),
                "public": True,
            },
        },
    },
    "user": {
        "password": generate_password_hash("1234"),
        "drawings": {
            "yakitori": {
                "data": convert_image_to_array("./images/roast_chicken.png"),
                "public": False,
            },
            "firebird chan (?)": {
                "data": convert_image_to_array("./images/fbc.png"),
                "public": True,
            },
        },
    },
}


def get_user(username):
    return USERS.get(username)


def get_user_private_drawings(username):
    user = get_user(username)
    if user and "drawings" in user:
        return [
            {
            "username": username,
            "name": drawing_name,
            "data": drawing["data"],
            "width": len(drawing["data"][0]) if drawing["data"] else 0,
            "height": len(drawing["data"]),
            }
            for drawing_name, drawing in user["drawings"].items()
            if not drawing["public"] and drawing["data"]
        ]
    return None


def get_drawing(username, drawing_name):
    user = get_user(username)
    if user and "drawings" in user and drawing_name in user["drawings"]:
        drawing_data = user["drawings"][drawing_name]
        return Drawing(drawing_data["data"], drawing_data.get("public", False))
    return None


def get_all_public_drawings():
    public_drawings = []
    for username, user_data in USERS.items():
        for drawing_name, drawing in user_data.get("drawings", {}).items():
            if drawing.get("public", False):
                public_drawings.append(
                    {
                        "username": username,
                        "name": drawing_name,
                        "data": drawing["data"],
                        "width": len(drawing["data"][0]) if drawing["data"] else 0,
                        "height": len(drawing["data"]),
                    }
                )
    return public_drawings
