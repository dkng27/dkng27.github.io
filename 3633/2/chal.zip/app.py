from flask import Flask, request, render_template, redirect, make_response
from selenium import webdriver
import logging
import os
import uuid

app = Flask(__name__)
# log = logging.getLogger('werkzeug')
# log.setLevel(logging.ERROR)

FLAG = os.environ.get("FLAG", "what{a_flaggy_flagish_flag}")
ADMIN_PW = os.environ.get("ADMIN_PW", "very_secure_password")

css_storage = {}

@app.route('/')
def index():
    css_id = request.args.get('id', None)
    css = css_storage.get(css_id, '')
    if css_id is not None and css_id not in css_storage:
        return redirect('/')
    return render_template('main.html', css=css, css_id=css_id)

@app.route('/save_css', methods=['POST'])
def save_css():
    css = request.form.get('css', '')
    css_id = str(uuid.uuid4())    
    css_storage[css_id] = css
    return redirect(f'/?id={css_id}')

@app.route('/css/<css_id>')
def get_css(css_id):
    css = css_storage.get(css_id, '')
    response = make_response(css)
    response.headers['Content-Type'] = 'text/css'
    return response

@app.route('/flag')
def flag_page():
    is_admin = request.args.get('admin_secret', '') == ADMIN_PW
    css_id = request.args.get('id', None)
    if not css_id or css_id not in css_storage:
        return "CSS not found", 404
    
    css_url = f'/css/{css_id}'
    return render_template('flag.html', is_bot=is_admin, flag=FLAG if is_admin else "No flag", css_url=css_url)

@app.route('/review', methods=['POST'])
def review():
    css_id = request.form.get('id', '')
    if not css_id or css_id not in css_storage:
        return "CSS not found", 404
    review_design(css_id)
    return "Firebird Chan (?) is now looking at your design~"

def review_design(css_id):
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-gpu')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--window-size=1920,1080')
    driver = webdriver.Chrome(options=chrome_options)
    driver.implicitly_wait(5)
    driver.get(f'http://localhost:80/flag?id={css_id}&admin_secret={ADMIN_PW}')
    driver.quit()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)
